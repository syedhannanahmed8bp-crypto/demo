/* ============================================================
   SMART TIMETABLE GENERATOR - MAIN LOGIC
   ============================================================
   This file handles:
   1. Storing subjects
   2. Adding / deleting subjects
   3. Generating a conflict-free timetable using a constraint-based
      greedy algorithm
   4. Displaying results
   ============================================================ */

/* ---------- GLOBAL DATA ---------- */

// Array that stores all subjects added by the user.
// Each subject looks like: { name: "C++", faculty: "Kumar", periods: 4 }
let subjects = [];

// This will store the last generated timetable structure so that
// "Regenerate" can be used without re-entering subjects.
// timetable[dayIndex][periodIndex] = { subject, faculty } or null (free)
let lastTimetable = null;

// Day names used for display. We only show as many as "workingDays" selects.
const ALL_DAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];


/* ============================================================
   1. ADD SUBJECT
   ============================================================ */
function addSubject() {
  const nameInput = document.getElementById("subjectName");
  const facultyInput = document.getElementById("facultyName");
  const periodsInput = document.getElementById("periodsPerWeek");

  const name = nameInput.value.trim();
  const faculty = facultyInput.value.trim();
  const periods = parseInt(periodsInput.value, 10);

  // ---- Validation ----
  if (name === "") {
    showStatus("Please enter a subject name.", "error");
    return;
  }

  if (faculty === "") {
    showStatus("Please enter a faculty name.", "error");
    return;
  }

  if (isNaN(periods) || periods <= 0) {
    showStatus("Periods per week must be a positive number.", "error");
    return;
  }

  if (periods > 20) {
    showStatus("That seems too many periods per week for one subject. Please re-check.", "error");
    return;
  }

  // Prevent duplicate subject names (case-insensitive)
  const duplicate = subjects.some(
    (s) => s.name.toLowerCase() === name.toLowerCase()
  );
  if (duplicate) {
    showStatus(`Subject "${name}" has already been added.`, "error");
    return;
  }

  // ---- Add to array ----
  subjects.push({ name: name, faculty: faculty, periods: periods });

  // ---- Update UI ----
  displaySubjects();
  clearAddSubjectFields();
  showStatus(`Subject "${name}" added successfully.`, "success");
}


/* ============================================================
   2. DISPLAY SUBJECTS
   ============================================================ */
function displaySubjects() {
  const list = document.getElementById("subjectList");
  list.innerHTML = ""; // clear existing list

  if (subjects.length === 0) {
    list.innerHTML = '<li class="empty-msg">No subjects added yet.</li>';
    return;
  }

  subjects.forEach((subject, index) => {
    const li = document.createElement("li");

    li.innerHTML = `
      <div class="subject-info">
        <span><strong>${index + 1}. ${escapeHtml(subject.name)}</strong></span>
        <span class="badge">${escapeHtml(subject.faculty)}</span>
        <span>${subject.periods} periods/week</span>
      </div>
      <button class="btn-delete" onclick="deleteSubject(${index})">Delete</button>
    `;

    list.appendChild(li);
  });
}


/* ============================================================
   3. DELETE SUBJECT
   ============================================================ */
function deleteSubject(index) {
  const removed = subjects[index];
  subjects.splice(index, 1);
  displaySubjects();
  showStatus(`Removed subject "${removed.name}".`, "success");

  // If a timetable was already generated, clear it since data changed
  lastTimetable = null;
  document.getElementById("timetableOutput").innerHTML =
    '<p class="empty-msg">Your timetable will appear here after generation.</p>';
}


/* ============================================================
   4. CLEAR ALL SUBJECTS
   ============================================================ */
function clearSubjects() {
  subjects = [];
  lastTimetable = null;

  displaySubjects();
  document.getElementById("timetableOutput").innerHTML =
    '<p class="empty-msg">Your timetable will appear here after generation.</p>';
  showStatus("All subjects cleared.", "success");
}


/* ============================================================
   5. LOAD SAMPLE DATA
   ============================================================ */
function loadSampleData() {
  subjects = [
    { name: "C++", faculty: "Kumar", periods: 4 },
    { name: "DBMS", faculty: "Priya", periods: 4 },
    { name: "Mathematics", faculty: "Ravi", periods: 5 },
    { name: "Python", faculty: "Kumar", periods: 3 },
    { name: "Computer Networks", faculty: "Ahmed", periods: 3 }
  ];

  displaySubjects();
  showStatus("Sample data loaded.", "success");
}


/* ============================================================
   6. HELPER: CLEAR INPUT FIELDS
   ============================================================ */
function clearAddSubjectFields() {
  document.getElementById("subjectName").value = "";
  document.getElementById("facultyName").value = "";
  document.getElementById("periodsPerWeek").value = "";
}


/* ============================================================
   7. HELPER: SHOW STATUS MESSAGE
   ============================================================ */
function showStatus(message, type) {
  const statusBox = document.getElementById("statusMessage");
  statusBox.textContent = message;
  statusBox.className = "status-message " + type; // success | error | warning
}


/* ============================================================
   8. HELPER: ESCAPE HTML (basic safety for user text)
   ============================================================ */
function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}


/* ============================================================
   9. VALIDATE INPUTS BEFORE GENERATING TIMETABLE
   ============================================================ */
function validateInputs(workingDays, periodsPerDay, maxFacultyPerDay) {
  if (subjects.length === 0) {
    showStatus("Please add at least one subject before generating a timetable.", "error");
    return false;
  }

  if (isNaN(maxFacultyPerDay) || maxFacultyPerDay <= 0) {
    showStatus("Maximum faculty classes per day must be a positive number.", "error");
    return false;
  }

  const totalSlots = workingDays * periodsPerDay;
  const totalRequired = subjects.reduce((sum, s) => sum + s.periods, 0);

  if (totalRequired > totalSlots) {
    showStatus(
      `Not enough timetable slots.\nRequired: ${totalRequired}\nAvailable: ${totalSlots}\n` +
      `Try adding more working days/periods per day, or reduce subject periods.`,
      "error"
    );
    return false;
  }

  return true;
}


/* ============================================================
   10. GENERATE TIMETABLE (MAIN ALGORITHM)
   ============================================================
   STRATEGY (simple constraint-based greedy algorithm):

   Step 1: Read settings (days, periods/day, max faculty/day, break).
   Step 2: Validate inputs.
   Step 3: Build a "request queue" of periods to place. Instead of
           putting all periods of one subject together, we go
           round-robin through subjects (Subject A, B, C, A, B, C...)
           so that periods get naturally distributed across the week
           instead of clumping on one day.
   Step 4: For each request in the queue, scan through every
           (day, period) slot in order and place the subject in the
           FIRST slot that satisfies all constraints:
             - the slot is empty
             - the faculty is not already teaching another subject
               in that same period on that day
             - the faculty has not already reached their maximum
               allowed classes for that day
             - the subject is not the same as the subject placed in
               the immediately previous period of that day
               (avoids back-to-back repetition)
   Step 5: If no slot satisfies ALL constraints, we relax the "no
           back-to-back repetition" rule and try again. This keeps
           the timetable valid (no faculty clashes, no daily-limit
           violations) even if perfect distribution isn't possible.
   Step 6: If a period truly cannot be placed anywhere without
           breaking a hard constraint (faculty clash / daily limit),
           it is recorded as "unplaced" and reported to the user.
   Step 7: Any leftover empty slots are marked as "Free".
   ============================================================ */
function generateTimetable(isRegenerate = false) {
  // ---- Step 1: Read settings ----
  const workingDays = parseInt(document.getElementById("workingDays").value, 10);
  const periodsPerDay = parseInt(document.getElementById("periodsPerDay").value, 10);
  const maxFacultyPerDay = parseInt(document.getElementById("maxFacultyPerDay").value, 10);
  const breakAfter = parseInt(document.getElementById("breakAfterPeriod").value, 10);

  // ---- Step 2: Validate ----
  if (!validateInputs(workingDays, periodsPerDay, maxFacultyPerDay)) {
    return;
  }

  // ---- Step 3: Build the timetable grid ----
  // grid[day][period] = null (empty) OR { name, faculty }
  const grid = [];
  for (let d = 0; d < workingDays; d++) {
    grid.push(new Array(periodsPerDay).fill(null));
  }

  // Track how many classes each faculty member has on each day.
  // facultyDailyCount[day][facultyName] = count
  const facultyDailyCount = [];
  for (let d = 0; d < workingDays; d++) {
    facultyDailyCount.push({});
  }

  // ---- Build round-robin request queue ----
  // We make a working copy of subjects with a "remaining" counter,
  // and randomize the subject order slightly on regenerate so a
  // different (but still valid) arrangement can be produced.
  let workingSubjects = subjects.map((s) => ({
    name: s.name,
    faculty: s.faculty,
    remaining: s.periods
  }));

  if (isRegenerate) {
    workingSubjects = shuffleArray(workingSubjects);
  }

  const requestQueue = [];
  let anyRemaining = true;
  while (anyRemaining) {
    anyRemaining = false;
    for (const subj of workingSubjects) {
      if (subj.remaining > 0) {
        requestQueue.push({ name: subj.name, faculty: subj.faculty });
        subj.remaining--;
        if (subj.remaining > 0) anyRemaining = true;
      }
    }
  }

  // ---- Step 4-6: Place each request into the grid ----
  const unplacedRequests = [];

  requestQueue.forEach((request) => {
    const placed = tryPlaceRequest(
      request,
      grid,
      facultyDailyCount,
      workingDays,
      periodsPerDay,
      maxFacultyPerDay,
      true // respect "no back-to-back same subject" rule first
    );

    if (!placed) {
      // Relax the back-to-back rule and try again
      const placedRelaxed = tryPlaceRequest(
        request,
        grid,
        facultyDailyCount,
        workingDays,
        periodsPerDay,
        maxFacultyPerDay,
        false // ignore back-to-back rule
      );

      if (!placedRelaxed) {
        unplacedRequests.push(request);
      }
    }
  });

  // ---- Step 7: Save & Display ----
  lastTimetable = {
    grid: grid,
    workingDays: workingDays,
    periodsPerDay: periodsPerDay,
    breakAfter: breakAfter
  };

  displayTimetable(grid, workingDays, periodsPerDay, breakAfter);

  // ---- Report results to user ----
  if (unplacedRequests.length > 0) {
    // Count unplaced periods per subject for a clear message
    const counts = {};
    unplacedRequests.forEach((r) => {
      counts[r.name] = (counts[r.name] || 0) + 1;
    });
    const details = Object.keys(counts)
      .map((name) => `${name} (${counts[name]} period[s])`)
      .join(", ");

    showStatus(
      `Could not create a completely valid timetable with the selected constraints.\n` +
      `Unplaced: ${details}.\n` +
      `Try increasing the maximum faculty classes per day or adding more working days/periods.`,
      "warning"
    );
  } else {
    showStatus("Timetable generated successfully!", "success");
  }
}


/* ============================================================
   11. TRY TO PLACE A SINGLE REQUEST INTO THE GRID
   ============================================================
   Scans every (day, period) combination in order and places the
   request in the first slot that satisfies all active constraints.
   Returns true if placed, false otherwise.
   ============================================================ */
function tryPlaceRequest(
  request,
  grid,
  facultyDailyCount,
  workingDays,
  periodsPerDay,
  maxFacultyPerDay,
  avoidBackToBack
) {
  for (let day = 0; day < workingDays; day++) {
    for (let period = 0; period < periodsPerDay; period++) {

      // Constraint 1: slot must be empty
      if (grid[day][period] !== null) continue;

      // Constraint 2: faculty must not already be teaching this exact
      // period on this day (checked implicitly since only one subject
      // can occupy grid[day][period] anyway) -- but we ALSO need to make
      // sure the same faculty isn't double counted across subjects in
      // the same period. Since each period can only hold one subject,
      // a true "same period" clash is impossible in this grid design.
      // The real risk is the DAILY LIMIT below.

      // Constraint 3: faculty must not exceed max classes per day
      const currentCount = facultyDailyCount[day][request.faculty] || 0;
      if (currentCount >= maxFacultyPerDay) continue;

      // Constraint 4 (soft): avoid placing the same subject as the
      // immediately previous period on this day
      if (avoidBackToBack && period > 0) {
        const previousSlot = grid[day][period - 1];
        if (previousSlot && previousSlot.name === request.name) {
          continue;
        }
      }

      // All constraints satisfied -> place it
      grid[day][period] = { name: request.name, faculty: request.faculty };
      facultyDailyCount[day][request.faculty] = currentCount + 1;
      return true;
    }
  }

  return false; // no valid slot found
}


/* ============================================================
   12. REGENERATE TIMETABLE
   ============================================================ */
function regenerateTimetable() {
  if (subjects.length === 0) {
    showStatus("Add subjects first before regenerating a timetable.", "error");
    return;
  }
  generateTimetable(true);
}


/* ============================================================
   13. DISPLAY TIMETABLE AS HTML TABLE
   ============================================================ */
function displayTimetable(grid, workingDays, periodsPerDay, breakAfter) {
  const dayNames = ALL_DAY_NAMES.slice(0, workingDays);
  const output = document.getElementById("timetableOutput");

  let html = "<table>";

  // ---- Table header ----
  html += "<tr><th>Period</th>";
  dayNames.forEach((day) => {
    html += `<th>${day}</th>`;
  });
  html += "</tr>";

  // ---- Table body ----
  for (let period = 0; period < periodsPerDay; period++) {
    html += "<tr>";
    html += `<td class="period-label">Period ${period + 1}</td>`;

    for (let day = 0; day < workingDays; day++) {
      const slot = grid[day][period];

      if (slot === null) {
        html += `<td class="slot-free">Free</td>`;
      } else {
        html += `<td class="slot-filled">${escapeHtml(slot.name)}<small>${escapeHtml(slot.faculty)}</small></td>`;
      }
    }

    html += "</tr>";

    // Insert a break row if this period matches the selected break point
    if (breakAfter > 0 && period + 1 === breakAfter) {
      html += `<tr><td class="break-cell" colspan="${workingDays + 1}">BREAK</td></tr>`;
    }
  }

  html += "</table>";
  output.innerHTML = html;
}


/* ============================================================
   14. HELPER: SHUFFLE ARRAY (Fisher-Yates)
   ============================================================
   Used only when regenerating, so a different but still valid
   arrangement can be produced from the same subject list.
   ============================================================ */
function shuffleArray(array) {
  const copy = [...array];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}


/* ============================================================
   INITIAL PAGE LOAD
   ============================================================ */
document.addEventListener("DOMContentLoaded", () => {
  displaySubjects();
});
